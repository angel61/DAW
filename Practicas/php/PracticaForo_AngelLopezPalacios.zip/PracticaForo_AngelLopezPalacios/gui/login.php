<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foro</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>

<body>
    <div class="contenedor">
        <div class="titulo">
            <h1>Login</h1>
        </div>
        <div class="formulario">
            <form action="index.php" method="POST">
            <div class="fila"> <span> Nombre:</span> <input type="text" name="txtNombre" required></div>
                <div class="fila"> <span>Clave:</span> <input type="password" name="txtClave" required></div>
                <div class="botones"><input type="submit" value="Inicio"></div>
            </form>
        </div>
    </div>

</body>

</html>