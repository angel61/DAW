<div class="formulario">
    <form name="frm1" action="index.php" method="post">
        <table>
            <tr>
                <td>ID</td>
                <td><input type="text" name="id"></td>
            </tr>
            <tr>
                <td>Nombre</td>
                <td><input type="text" name="nombre"></td>
            </tr>
            <tr>
                <td>Apellidos</td>
                <td><input type="text" name="apellidos"></td>
            </tr>
            <tr>
                <td>Nacionalidad</td>
                <td><input type="text" name="nacionalidad"></td>
            </tr>
        </table>
        <div class="botones"><button name="btnAnnadir">Añadir</button>
            <button name="btnModificar">Modificar</button>
            <button name="btnBorrar">Borrar</button>
            <button name="btnMostrar">Mostrar</button>
        </div>
    </form>
</div>