<div class="tabla">
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Nacionalidad</th>
        </tr>
        <?php $this->printAutores(); ?>
    </table>
</div>